import 'package:flutter/material.dart';
import 'package:travel_aja/colors_theme.dart';

class NoPage extends StatefulWidget {
  String header;

  NoPage({Key key, this.header}) : super(key: key);

  @override
  _NoPageState createState() => _NoPageState();
}

class _NoPageState extends State<NoPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.header),
      ),
      body: Center(
       child: Text("Coming Soon", style: TextStyle(color: ColorsTheme.text1, fontWeight: FontWeight.bold, fontSize: 16),)
      ),
    );
  }
}