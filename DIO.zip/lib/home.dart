import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:line_awesome_icons/line_awesome_icons.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:travel_aja/api/service_api.dart';
import 'package:travel_aja/models/cls_data_master.dart';
import 'package:intl/intl.dart';
import 'package:travel_aja/widget/error_connection.dart';
import 'package:travel_aja/widget/progress_page.dart';

import 'camera_page.dart';
import 'colors_theme.dart';
import 'models/cls_home.dart';
import 'search_holiday.dart';


class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String nrp = "";
  SharedPreferences prefs;
  String dateNow = new DateFormat('EEE | MMM dd, yyyy').format(DateTime.now());// "Thue | Maret 03, 2020",
  bool loading = true;
  bool failed = true;
  String remarks;
  List listBanner = new List();
  List listWorldTrip = new List();
  List listDiscovery = new List();

  final List<MenuHome> listMenu = [
    MenuHome(
      "Camera",
      Icon(LineAwesomeIcons.camera_retro, color: ColorsTheme.primary1), 
      "Camera"
    ),
    MenuHome(
      "Train Ticket",
      Icon(LineAwesomeIcons.train, color: ColorsTheme.primary1), 
      "Train"
    ),
    MenuHome(
      "Bus Ticket",
      Icon(LineAwesomeIcons.bus, color: ColorsTheme.primary1),
      "Bus",
    ),
    MenuHome(
      "Car Rental",
      Icon(LineAwesomeIcons.car, color: ColorsTheme.primary1), 
      "Car"
    ),
    MenuHome(
      "Hotel", 
      Icon(LineAwesomeIcons.hotel, color: ColorsTheme.primary1),
      "Hotel"
    ),
    MenuHome(
      "Eats", 
      Icon(LineAwesomeIcons.glass, color: ColorsTheme.primary1),
      "Eats"),
    MenuHome(
      "Cinema",
      Icon(LineAwesomeIcons.file_movie_o, color: ColorsTheme.primary1),
      "Cinema"
    ),
    MenuHome(
      "Internet",
      Icon(LineAwesomeIcons.stack_overflow, color: ColorsTheme.primary1),
      "Internet"
    ),
  ];

  Future getPrefs() async{
    prefs = await SharedPreferences.getInstance();
    print(prefs.getString("token"));
    setState(() {
     nrp =  prefs.getString("username");
    });    
  }

  Future getData(BuildContext context) async{
    loading = true;
    failed = true;
    SharedPreferences pref = await SharedPreferences.getInstance();
    getClient()
    .getDataMaster(pref.getString("token"))
    .then((response) async {
      loading = false;
      if(response.status){
        setState(() {
          failed = false;
          listBanner = response.banner;
          listWorldTrip = response.worldTrip;
          listDiscovery = response.discovery;
        });
      }else{
        setState(() {
          failed = true;
          remarks = response.remarks;
        });
        // print(response.remarks);
      }
    }).catchError((Object obj){
      setState(() {
        loading = false;
        failed = true;
      });
      switch (obj.runtimeType){
        case DioError :
          final res =  (obj as DioError).response;
          setState(() {
            remarks = null ? "Failed connection to server" :  "${res.statusCode} - ${res.statusMessage}";
          }); 
          print("GOT ERROR : ${res.statusCode} -> ${res.statusMessage}");
          break;
        default:
      }
    });
  }

  @override
  void initState() {
    getPrefs();
    getData(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      body: loading ? ProgressPage() 
        : failed ? ErrorConnection(
          (){
            getData(context);
          }, remarks: remarks,) : 
      SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(
                top: 52, 
                bottom: 24, 
                left: 22, 
                right: 22
              ),
              child: Column(
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            dateNow,
                            style: TextStyle(
                              color: ColorsTheme.text2,
                              fontSize: 12,
                              fontWeight: FontWeight.w500
                            ),
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: <Widget>[
                              Text(
                                "Hi, ",
                                style: TextStyle(
                                  color: ColorsTheme.text2,
                                  fontSize: 22
                                ),
                              ),
                              Text(
                                nrp.toString(),
                                style: TextStyle(
                                  color: ColorsTheme.text1,
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold
                                ),
                              )
                            ],
                          )
                        ],
                      ),
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: ColorsTheme.bag1,
                          shape: BoxShape.circle
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(25),
                          child: Image.asset(
                            "assets/images/user.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 24,),
                  InkWell(
                    onTap: (){
                      Navigator.push(context, 
                        MaterialPageRoute(
                          builder: (context) => SearchHoliday(list_discovery: listDiscovery,)
                        )
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: ColorsTheme.bag1,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Icon(
                            Icons.search, 
                            color: ColorsTheme.primary1, 
                            size: 20,
                          ),
                          SizedBox(width: 16,),
                          Text(
                            "Search ...",
                            style: TextStyle(
                              fontSize: 14,
                              color: ColorsTheme.text2
                            )
                          )

                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            buildBanner(context, listBanner),
            Padding(
              padding: const EdgeInsets.only(top: 1, bottom: 16, left: 16, right: 16),
              child: buildMenu(context, listMenu),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 32, left: 24, right: 22),
              child: Text(
                "Place To Visit This Winter",
                style: TextStyle(
                  color: ColorsTheme.text1,
                  fontSize: 18,
                  fontWeight: FontWeight.bold
                ),
              ),
            ),
            SizedBox(
              height: 200,
              child: buildWorldTrip(context, listWorldTrip)
            ),
            Padding(
              padding: const EdgeInsets.only(top: 32, bottom: 8, left: 24, right: 22),
              child: Text(
                "International Holiday Packages",
                style: TextStyle(
                  color: ColorsTheme.text1,
                  fontSize: 18,
                  fontWeight: FontWeight.bold
                ),
              ),
            ),
            Padding( padding: EdgeInsets.only(bottom: 20), child: buildDiscovery(context, listDiscovery))
          ],
        ),
      )
    );
  }

  Widget buildBanner(BuildContext context, List<String> listbanner){
    return CarouselSlider(
      aspectRatio: 9 / 4,
      viewportFraction: 0.92,
      initialPage: 0,
      enableInfiniteScroll: true,
      reverse: false,
      autoPlay: true,
      autoPlayInterval: Duration(seconds: 5),
      autoPlayAnimationDuration: Duration(milliseconds: 500),
      autoPlayCurve: Curves.fastOutSlowIn,
      pauseAutoPlayOnTouch: Duration(seconds: 5),
      enlargeCenterPage: true,
      // onPageChanged: callbackFunction,
      scrollDirection: Axis.horizontal, 
      items: listbanner.map((index){
        return Builder(
          builder: (context){
            return Container(
              width: MediaQuery.of(context).size.width,
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)
                ),
                elevation: 2,
                color: ColorsTheme.bag1,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: CachedNetworkImage(
                    imageUrl: index,
                    fit: BoxFit.cover,
                  ),
                )
              ),
            );
          },
        );
      }).toList()
    );
  }

  Widget buildMenu(BuildContext context, List listmenu){
    return GridView.count(
      crossAxisCount: 4,
      crossAxisSpacing: 4,
      mainAxisSpacing: 28,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      children: List.generate(listmenu.length, (index){
        MenuHome item = listmenu[index];
        return InkWell(
          onTap: (){
            Navigator.pushNamed(context, 
              "/"+item.route, arguments: item.menu
            );
          },
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                width: 45,
                height: 45,
                decoration: BoxDecoration(
                  color: ColorsTheme.bag1,
                  shape: BoxShape.circle
                ),
                child: item.icons,
              ),
              SizedBox(height: 8,),
              Text(
                item.menu,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  // color: 
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget buildWorldTrip(BuildContext context, List listWorldTrip){
    return ListView.builder(
      scrollDirection: Axis.horizontal,
      physics: ClampingScrollPhysics(),
      padding: EdgeInsets.only(top: 8),
      shrinkWrap: true,
      itemCount: listWorldTrip.length,
      itemBuilder: (context, index){
        Discovery item = listWorldTrip[index];
        bool first = index == 0;
        bool last = listWorldTrip.length == (index + 1);
        return Container(
          margin: EdgeInsets.only(left: first ? 16 : 0, right: last ? 16 : 0),
          padding: EdgeInsets.only(left: 4, right: 4),
          width: MediaQuery.of(context).size.width * 0.4,
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8)
            ),
            elevation: 2,
            color: Colors.white,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: CachedNetworkImage(
                imageUrl: item.image,
                fit: BoxFit.cover
              ),
            ),
          ),
        );
      },
    );
  }

  Widget buildDiscovery(BuildContext context, List listDiscovery){
    return ListView.builder(
      padding: EdgeInsets.only(top: 0),
      scrollDirection: Axis.vertical,
      itemCount: listDiscovery.length,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemBuilder: (context, index){
        Discovery item = listDiscovery[index];
        return InkWell(
          onTap: (){

          },
          child: Padding(
            padding: EdgeInsets.only(left: 22, right: 22, top: 4, ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Row(
                  // crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width * 0.2,
                      height: 64,
                      child: Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)
                        ),
                        elevation: 2,
                        color: Colors.white,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: CachedNetworkImage(
                            imageUrl: item.image,
                            fit: BoxFit.cover
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left:6.0, right: 6.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              item.header,
                              style: TextStyle(
                                fontSize: 14,
                                color: ColorsTheme.text1,
                                fontWeight: FontWeight.w500
                              ),
                            ),
                            SizedBox(height: 4,),
                            Text(
                              item.sub_header,
                              style: TextStyle(
                                fontSize: 12,
                                color: ColorsTheme.primary1
                              ),
                            ),
                            SizedBox(height: 4,),
                            Text(
                              item.body,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 12,
                                color: ColorsTheme.text2,
                      
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Icon(
                      LineAwesomeIcons.angle_right, 
                      color: ColorsTheme.text2, 
                      size: 14,
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Divider(height: 1,),
                )
              ],
            ),
          ),
        );
      },
    );
  }

}