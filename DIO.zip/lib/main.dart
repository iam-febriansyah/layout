import 'package:flutter/material.dart';
import 'package:travel_aja/splash_screen.dart';
import 'package:travel_aja/widget/route_generator.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Travell Aja',
      theme: ThemeData(
        fontFamily: 'Montserrat',
        primarySwatch: Colors.green,
      ),
      initialRoute: "/",
      onGenerateRoute: RouteGenerator.generator,
      home: SplashScreen(),
    );
  }
}

