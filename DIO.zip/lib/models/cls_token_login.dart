import 'dart:convert';

ClsTokenLogin clsTokenLoginFromJson(String str) => ClsTokenLogin.fromJson(json.decode(str));

String clsTokenLoginToJson(ClsTokenLogin data) => json.encode(data.toJson());

class ClsTokenLogin {
    String token;
    int expired;
    String expiredDate;
    bool success;
    String pidUser;
    String district;
    bool isPasswordDefault;
    String remarks;

    ClsTokenLogin({
        this.token,
        this.expired,
        this.expiredDate,
        this.success,
        this.pidUser,
        this.district,
        this.isPasswordDefault,
        this.remarks,
    });

    factory ClsTokenLogin.fromJson(Map<String, dynamic> json) => ClsTokenLogin(
        token: json["token"],
        expired: json["expired"],
        expiredDate: json["expired_date"],
        success: json["success"],
        pidUser: json["pid_user"],
        district: json["district"],
        isPasswordDefault: json["is_password_default"],
        remarks: json["remarks"],
    );

    Map<String, dynamic> toJson() => {
        "token": token,
        "expired": expired,
        "expired_date": expiredDate,
        "success": success,
        "pid_user": pidUser,
        "district": district,
        "is_password_default": isPasswordDefault,
        "remarks": remarks,
    };
}