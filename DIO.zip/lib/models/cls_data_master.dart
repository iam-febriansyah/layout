// To parse this JSON data, do
//
//     final clsDataMaster = clsDataMasterFromJson(jsonString);

import 'dart:convert';

ClsDataMaster clsDataMasterFromJson(String str) => ClsDataMaster.fromJson(json.decode(str));

String clsDataMasterToJson(ClsDataMaster data) => json.encode(data.toJson());

class ClsDataMaster {
    bool status;
    String remarks;
    List<String> banner;
    List<Discovery> worldTrip;
    List<Discovery> discovery;

    ClsDataMaster({
        this.status,
        this.remarks,
        this.banner,
        this.worldTrip,
        this.discovery,
    });

    factory ClsDataMaster.fromJson(Map<String, dynamic> json) => ClsDataMaster(
        status: json["status"],
        remarks: json["remarks"],
        banner: List<String>.from(json["banner"].map((x) => x)),
        worldTrip: List<Discovery>.from(json["world_trip"].map((x) => Discovery.fromJson(x))),
        discovery: List<Discovery>.from(json["discovery"].map((x) => Discovery.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "remarks": remarks,
        "banner": List<dynamic>.from(banner.map((x) => x)),
        "world_trip": List<dynamic>.from(worldTrip.map((x) => x.toJson())),
        "discovery": List<dynamic>.from(discovery.map((x) => x.toJson())),
    };
}

class Discovery {
    String header;
    String sub_header;
    String body;
    String image;

    Discovery({
        this.header,
        this.sub_header,
        this.body,
        this.image,
    });

    factory Discovery.fromJson(Map<String, dynamic> json) => Discovery(
        header: json["header"],
        sub_header: json["sub_header"],
        body: json["body"],
        image: json["image"],
    );

    Map<String, dynamic> toJson() => {
        "header": header,
        "sub_header": sub_header,
        "body": body,
        "image": image,
    };
}
