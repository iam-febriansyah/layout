import 'package:flutter/material.dart';

class MenuHome{
  String menu;
  Icon icons;
  String route;

  MenuHome(this.menu, this.icons, this.route);

}