import 'package:flutter/material.dart';
import 'package:line_awesome_icons/line_awesome_icons.dart';

class Notif{
  Icon icons;
  String header;
  String time;
  String body;
  String image;

  Notif(this.icons, this.header, this.time, this.body, this.image );
}