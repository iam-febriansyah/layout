// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'service_api.dart';

// **************************************************************************
// RetrofitGenerator
// **************************************************************************

class _RestClient implements RestClient {
  _RestClient(this._dio, {this.baseUrl}) {
    ArgumentError.checkNotNull(_dio, '_dio');
    this.baseUrl ??= 'https://apimobile.pamapersada.com:27941/api/';
  }

  final Dio _dio;

  String baseUrl;

  @override
  getToken(username, password) async {
    ArgumentError.checkNotNull(username, 'username');
    ArgumentError.checkNotNull(password, 'password');
    const _extra = <String, dynamic>{};
    final queryParameters = <String, dynamic>{};
    final _data = {'username': username, 'password': password};
    final Response<Map<String, dynamic>> _result = await _dio.request('token',
        queryParameters: queryParameters,
        options: RequestOptions(
            method: 'POST',
            headers: <String, dynamic>{},
            extra: _extra,
            baseUrl: baseUrl),
        data: _data);
    final value = ClsTokenLogin.fromJson(_result.data);
    return Future.value(value);
  }

  @override
  getDataMaster(Authorization) async {
    ArgumentError.checkNotNull(Authorization, 'Authorization');
    const _extra = <String, dynamic>{};
    final queryParameters = <String, dynamic>{};
    final _data = <String, dynamic>{};
    final Response<Map<String, dynamic>> _result = await _dio.request(
        'Training/GetDataMaster',
        queryParameters: queryParameters,
        options: RequestOptions(
            method: 'GET',
            headers: <String, dynamic>{'Authorization': Authorization},
            extra: _extra,
            baseUrl: baseUrl),
        data: _data);
    final value = ClsDataMaster.fromJson(_result.data);
    return Future.value(value);
  }
}
