import 'package:dio/dio.dart';
import 'package:retrofit/http.dart';
import 'package:travel_aja/models/cls_data_master.dart';
import 'package:travel_aja/models/cls_token_login.dart';

part 'service_api.g.dart';

@RestApi(baseUrl: "https://apimobile.pamapersada.com:27941/api/")
abstract class RestClient {
  factory RestClient(Dio dio) = _RestClient;

  @POST("token")
  Future<ClsTokenLogin> getToken(
    @Field("username") String username,
    @Field("password") String password,
  );

  @GET("Training/GetDataMaster")
  Future<ClsDataMaster> getDataMaster(
    @Header("Authorization") String Authorization, 
  );
}

RestClient getClient({String header}){
  final dio = Dio();

  dio.options.headers["Content-Type"] = header == null || header.isEmpty ? "application/json" : header ;
  dio.options.connectTimeout = 60000;

  RestClient client = RestClient(dio);
  return client;
}