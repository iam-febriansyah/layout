import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:travel_aja/colors_theme.dart';
import 'package:travel_aja/login.dart';

class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  Future logout(BuildContext context) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    setState(() {
     pref.clear(); 
    });
    Navigator.pushReplacement(context, 
      MaterialPageRoute(builder: (contex) => Login()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          margin: EdgeInsets.only(left: 22, right: 22),
          width: MediaQuery.of(context).size.width,
          height: 60,
          child: RaisedButton(
            onPressed: (){
              logout(context);
            },
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(6)
            ),
            color: ColorsTheme.primary1,
            child: Text(
              "Sign Out",
              style: TextStyle(
                fontSize: 16,
                color: Colors.white
              ),
            ),
          ),
        ),
      ),
    );
  }
}