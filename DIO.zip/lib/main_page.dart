import 'package:flutter/material.dart';
import 'package:line_awesome_icons/line_awesome_icons.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:travel_aja/camera_page.dart';
import 'package:travel_aja/colors_theme.dart';
import 'package:travel_aja/login.dart';
import 'package:travel_aja/profile.dart';

import 'home.dart';
import 'notifications.dart';

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;
  List<Widget> pages = [
    Home(),
    Notifications(),
    Profile()
  ];

  _onItemTap(int index){
    setState(() {
     _selectedIndex = index; 
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: pages.elementAt(_selectedIndex),
      ),
      // floatingActionButton: FloatingActionButton(
      //   elevation: 2,
      //   onPressed: () async {
      //     Navigator.pushReplacement(context, 
      //       MaterialPageRoute(
      //         builder: (context) => CameraPage()
      //       )
      //     );
      //   },
      //   child: Icon(LineAwesomeIcons.camera_retro),
      //   backgroundColor: ColorsTheme.primary1,
      // ),

      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(LineAwesomeIcons.home),
            title: Text(
              "Home",
              style: TextStyle(

              ),
            )
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications),
            title: Text(
              "Notifications",
              style: TextStyle(
                
              ),
            )
          ),
          BottomNavigationBarItem(
            icon: Icon(LineAwesomeIcons.user),
            title: Text(
              "Profile",
              style: TextStyle(
                
              ),
            )
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: ColorsTheme.primary1,
        unselectedItemColor: ColorsTheme.line1,
        onTap: _onItemTap,
      ),
      
    );
  }
}