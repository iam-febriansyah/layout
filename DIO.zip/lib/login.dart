import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:travel_aja/api/service_api.dart';
import 'package:travel_aja/colors_theme.dart';
import 'package:travel_aja/main_page.dart';
import 'package:travel_aja/widget/progress.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  bool obscurePassword = true;
  String validator;
  TextEditingController ctrlUsername = new TextEditingController();
  TextEditingController ctrlPassword = new TextEditingController();
  final _formKey = GlobalKey<FormState>();

  Future login(BuildContext context) async{
    SharedPreferences pref = await SharedPreferences.getInstance(); 
    showDialog(
      context: context,
      builder: (context) => ProgressSubmit(),
      barrierDismissible: false
    );
    getClient(header: "application/x-www-form-urlencoded")
    .getToken(ctrlUsername.text, ctrlPassword.text)
    .then((response) async {
      Navigator.pop(context);
      if(response.success){
        String iUsernameOri = ctrlUsername.text;
        String iUsername = ctrlUsername.text.substring(1);

        pref.setString("token", response.token);
        pref.setString("username", iUsername);
        pref.setString("pUsername", iUsernameOri);
        pref.setString("district", response.district);
        pref.setString("pidUser", response.pidUser);
        pref.setString("expiredDate", response.expiredDate);
        pref.setBool("isLogin", true);
        Navigator.pushReplacement(context, 
          MaterialPageRoute(
            builder: (context) => MainPage()
          )
        );
      }else{
        setState(() {
          validator = response.remarks;
        });
        print(response.remarks);
      }
    }).catchError((Object obj){
      switch (obj.runtimeType){
        case DioError :
          final res =  (obj as DioError).response;
          print("GOT ERROR : ${res.statusCode} -> ${res.statusMessage}");
          break;
        default:
      }
    });
  }


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    obscurePassword = true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.only(left: 32, right: 32, top: 52, bottom: 32),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    width: 100,
                    height: 100,
                    child: ClipRRect(
                      child: Image.asset(
                        "assets/images/plane.png",
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  SizedBox(height: 22,),
                  Text(
                    "Welcome,",
                    style: TextStyle(
                      fontSize: 36, 
                      fontWeight: FontWeight.bold, 
                      color: ColorsTheme.text1,
                      fontFamily: "Indie_Flower"
                    ),
                  ),
                  SizedBox(height: 12,),
                  Text(
                    "Sign in to continue",
                    style: TextStyle(
                      color: ColorsTheme.text2,
                      fontSize: 16,
                      fontWeight: FontWeight.bold
                    ),
                  ),
                  SizedBox(height: 42,),
                  TextFormField(
                    validator: (String arg){
                      if(arg==null || arg.isEmpty){
                        return "Please enter username";
                      }else{
                        return null;
                      }
                    },
                    controller: ctrlUsername,
                    style: TextStyle(
                      color: ColorsTheme.text1,
                      fontSize: 16
                    ),
                    cursorColor: ColorsTheme.primary1,
                    decoration: InputDecoration(
                      labelText: "Username",
                      labelStyle: TextStyle(fontSize: 16),
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: ColorsTheme.line2.withOpacity(0.4),
                          width: 1.5
                        )
                      ),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: ColorsTheme.primary1.withOpacity(0.5),
                          width: 1.5
                        )
                      )
                    ),
                  ),
                  SizedBox(height: 24,),
                  TextFormField(
                    validator: (String arg){
                      if(arg==null || arg.isEmpty){
                        return "Please enter password";
                      }else{
                        return null;
                      }
                    },
                    controller: ctrlPassword,
                    obscureText: obscurePassword,
                    style: TextStyle(
                      color: ColorsTheme.text1,
                      fontSize: 16
                    ),
                    cursorColor: ColorsTheme.primary1,
                    decoration: InputDecoration(
                      suffixIcon: IconButton(
                        onPressed: (){
                          setState(() {
                           obscurePassword = !obscurePassword; 
                          });
                        },
                        icon: Icon( 
                          obscurePassword ?  Icons.visibility : Icons.visibility_off,
                          color: ColorsTheme.line1.withOpacity(0.6),
                          size: 24,
                        ),
                      ),
                      labelText: "Password",
                      labelStyle: TextStyle(fontSize: 16),
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: ColorsTheme.line2.withOpacity(0.4),
                          width: 1.5
                        )
                      ),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: ColorsTheme.primary1.withOpacity(0.5),
                          width: 1.5
                        )
                      )
                    ),
                  ),
                  validator != null ?
                  Text(
                    validator.toString(),
                    style: TextStyle(
                      color: Colors.red,
                      fontSize: 14
                    ),
                  ) : Container(),
                  SizedBox(height: 60),
                  MaterialButton(
                    onPressed: (){
                      if(_formKey.currentState.validate()){
                        login(context);
                      }
                      // else{
                      //   print("Username & Password is required");
                      //   Alert(
                      //     context: context,
                      //     type: AlertType.info,
                      //     title: "Warning",
                      //     desc: "Username & Password is required",
                      //     buttons: [
                      //       DialogButton(
                      //         child: Text(
                      //           "Close",
                      //           style: TextStyle(color: Colors.white, fontSize: 20),
                      //         ),
                      //         onPressed: () => Navigator.pop(context),
                      //         width: 120,
                      //       )
                      //     ],
                      //   ).show();
                      // }
                    },
                    color: ColorsTheme.primary1,
                    height: 46,
                    minWidth: MediaQuery.of(context).size.width,
                    elevation: 0,
                    textColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25)
                    ),
                    child: Text(
                      "Sign In"
                    ),
                  ),
                  SizedBox(height: 24),
                  Center(
                    child: Text(
                      "Forgot Password? Let us help",
                      style: TextStyle(
                        color: ColorsTheme.text2,
                        fontSize: 14
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
