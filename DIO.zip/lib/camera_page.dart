import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:line_awesome_icons/line_awesome_icons.dart';

class CameraPage extends StatefulWidget {
  @override
  _CameraPageState createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> {
  File fileImage;

  Future getImageFromCamera() async {
    Navigator.pop(context);
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    setState(() {
     fileImage = image; 
    });
  }

  Future getImageFromGallery() async {
    Navigator.pop(context);
    var image = await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
     fileImage = image; 
    });
  }

  Future showDialogPilihan(){
    return showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context){
        return AlertDialog(
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(8),
                  child: InkWell(
                    child: Text(
                      "Take a Photo",
                    ),
                    onTap: (){
                      getImageFromCamera();
                    },
                  )
                ),
                Padding(
                  padding: EdgeInsets.all(8),
                  child: InkWell(
                    child: Text(
                      "Select Image from Gallery",
                    ),
                    onTap: (){
                      getImageFromGallery();
                    },
                  )
                )
              ],
            ),
          ),
        );
      }
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Camera Page"),
      ),
      body: Center(
        child: fileImage == null ? 
          Text(
            "Tidak ada gambar yang di pilih"
          ) 
          : Image.file(fileImage),
      ),
      floatingActionButton: FloatingActionButton(
        tooltip: "Add Photo",
        child: Icon(LineAwesomeIcons.camera_retro),
        onPressed: (){
          showDialogPilihan();
        },
      ),
    );
  }
}

