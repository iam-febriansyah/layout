import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'colors_theme.dart';
import 'login.dart';
import 'main_page.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  
  checkSession() {
    var duration = Duration(seconds: 3);
    return Timer(duration, () async{
      SharedPreferences prefs = await SharedPreferences.getInstance();
        Navigator.pushReplacement(context, 
          MaterialPageRoute(
            builder: (context) => prefs.getBool("isLogin") == null || prefs.getBool("isLogin") == false ? Login() : MainPage()
          )
        );
    });
    
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    checkSession();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 150,
              height: 150,
              child: ClipRRect(
                child: Image.asset(
                  "assets/images/plane.png",
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(
              height: 12,
            ),
            Text(
              "Travel Aja!",
              style: TextStyle(
                color: ColorsTheme.text1.withOpacity(0.5),
                fontWeight: FontWeight.bold,
                fontSize: 24
              ),
            )
          ],
        ),
      ),
    );
  }
}