import 'package:flutter/material.dart';

import '../colors_theme.dart';

class ErrorConnection extends StatelessWidget {
  Function onRetry;
  String remarks;

  ErrorConnection(this.onRetry, {this.remarks});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.only(left: 16, right: 16, top: 42, bottom: 42),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text("I'm Lost",
              style: TextStyle(
                color: ColorsTheme.text1,
                height: 1.1,
                fontSize: 22,
                fontWeight: FontWeight.bold
              )
            ),
            SizedBox(height: 8),
            Text(
              remarks == null
                ? "You failed to connect the server!"
                : remarks.toString(),
              textAlign: TextAlign.center,
              style: TextStyle(
                height: 1.2, fontSize: 14, color: ColorsTheme.text2,
              )
            ),
            Padding(
              padding: EdgeInsets.only(top: 8),
              child: RaisedButton(
                onPressed: () {
                  onRetry();
                },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6)),
                color: ColorsTheme.primary1,
                child: Text(
                  "Try Again",
                  style: TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
            )
          ],
        )
      )
    );
  }
}