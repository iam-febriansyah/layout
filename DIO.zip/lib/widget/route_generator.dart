import 'package:flutter/material.dart';
import 'package:travel_aja/camera_page.dart';
import 'package:travel_aja/main_page.dart';
import 'package:travel_aja/no_page.dart';
import 'package:travel_aja/notifications.dart';

class RouteGenerator {
  
  static Route<dynamic>  generator(RouteSettings settings){
    final args = settings.arguments;

    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => MainPage());
        break;

      case '/Camera':
        return MaterialPageRoute(builder: (_) => CameraPage());
        break;

      case '/Notifications':
        return MaterialPageRoute(builder: (_) => Notifications());
        break;


      default:
        return MaterialPageRoute(builder: (_) => NoPage(header: args.toString(),));
      
    }
  }

}